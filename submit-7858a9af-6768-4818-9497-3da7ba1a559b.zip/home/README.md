# (Fairly used vehicle Dataset)

## by (IBRAHIM ALI)


## Dataset

> The data consists of information regarding 1,451 fairly used dataset in Nigeria, including
 price, engine, odometer, fuel and other vehicles qualities. 



## Summary of Findings

> Based on my exploratory analysis i found that the price of a vehicle in Nigeria
has a good relationship with vehicle engine cylinder,fuel type,transmission type, 
and foriegn or locally used vehicle. The price of a vehicles has a negative correlation with odometer reading, 
that is vehicle with higher odometer tend to be less expensive than the one with lower odometer. 
Most of the price of the commercial vehicle that used diesel as a fuel type have a poor correlation with odometer.

## Key Insights for Presentation

> For the presentation, I focus on the faetures that affect vehicle price in Nigeria. I start by introducing the
 price variable, followed by the pattern in price and odometer distribution, then plot the transformed scatterplot.
Afterwards, I introduce each of the categorical variables one by one. To start,
I use the scatter plots of price and odometer. The other four categorical
variables, engine, fuel, transmission and isimported i used dufferent univariate, 
bivariate and multivariate plot to answer my analysis questions. I've made
sure to use different color palettes for each quality variable to make sure it
is clear that they're different between plots..